Create env from yml file: `conda env create -f environment.yml`

Export env to yml file:    `conda env export > environment.yml`