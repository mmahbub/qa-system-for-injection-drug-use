import torch
import torch.nn as nn

dev = torch.device("cuda")

t1 = torch.randn(1,2)
t2 = torch.randn(1,2).to(dev)

t1.to(dev)
t1 = t1.to(dev)

print(t1, t1.is_cuda)

class M(nn.Module):
    def __init__(self):
        super().__init__()
        self.l1 = nn.Linear(1,2)
        
    def forward(self, x):
        x = self.l1(x)
        return x
    
model = M()
model.to(dev)

print(next(model.parameters()).is_cuda)
